AngularJS is manage by NUGetPackage manager
All AngularJS code is in the Script folder. Todo maybee change or rename the location.