'use strict';

angular.module('MyModule').service('StorageService', ['$log', '$q', function ($log, $q) {
}]);
